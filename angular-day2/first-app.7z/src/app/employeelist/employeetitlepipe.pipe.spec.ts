import { EmployeetitlepipePipe } from './employeetitlepipe.pipe';

describe('EmployeetitlepipePipe', () => {
  it('create an instance', () => {
    const pipe = new EmployeetitlepipePipe();
    expect(pipe).toBeTruthy();
  });
});
